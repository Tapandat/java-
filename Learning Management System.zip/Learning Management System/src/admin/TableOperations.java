package admin;

public interface TableOperations {
   void insert();
   void update();
   void showtable();
   void delete();
   void clear();
   void serch();
   void gettabledata();
}
