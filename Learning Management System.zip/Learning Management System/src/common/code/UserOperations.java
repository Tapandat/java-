package common.code;

public interface UserOperations {
    void logout();
    void back(Object parameter);
}
