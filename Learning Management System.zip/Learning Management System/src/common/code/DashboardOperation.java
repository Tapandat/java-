package common.code;

public interface DashboardOperation {
    void setAvatar();
    void updateEmail();
}
