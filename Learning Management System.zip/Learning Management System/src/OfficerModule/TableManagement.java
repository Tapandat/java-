/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package OfficerModule;

/**
 *
 * @author HP
 */
public interface TableManagement {
     void Reset();
     void Insert();
     void SetValue();
     void Referance();
     void ShowTable();
     void Update();
     
    
}
